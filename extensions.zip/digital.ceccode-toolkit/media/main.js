//@ts-check

// This script will be run within the webview itself
// It cannot access the main VS Code APIs directly.
(function () {
    const vscode = acquireVsCodeApi();

    $(".open-button").on("click", function () {
        console.log($(this).attr("cmd"));
        vscode.postMessage({
            command: $(this).attr("cmd")
        })
    });
    // document.querySelector('.open-button').addEventListener('click', () => {
    //     var cmd = this.querySelector('cmd');
    //     vscode.postMessage({
    //         command: cmd
    //     })
    // });


}());


