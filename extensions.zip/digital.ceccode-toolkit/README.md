# ceccode-toolkit README

CEC CODE 开发工具箱

## Features

用于集成开发工具，方便使用
## Requirements

CEC CODE 版本 大于等于 0.0.1


---

## 集成指引

- 添加集成的按钮
```
    const toolkit = vscode.extensions.getExtension<Map<string, Map<string, string>>>('digital.ceccode-toolkit');
	if (!toolkit) {
		throw new Error('toolkit not installed');
	}
	await toolkit.activate();
	const api = toolkit.exports;
	var valueMap = new Map<string, string>()
	// 按钮名称
	valueMap.set('title', '测试2');
	// 点击按钮发送的命令
	valueMap.set('command', 'sample-toolkit-webview.helloWorld');
    // 当前插件注册 到工具箱的唯一标识 ,前缀 是决定进入那个栏目，例如：ceccodeToolkit.devSidebarView 进入 开发工具 
	// 栏目枚举有： 
	/*{ displayName: '开发工具', viewType: 'ceccodeToolkit.devSidebarView'},
		{ displayName: '测试工具', viewType: 'ceccodeToolkit.testSidebarView'},
		{ displayName: '质量工具', viewType: 'ceccodeToolkit.qualitySidebarView'},
		{ displayName: '安全工具', viewType: 'ceccodeToolkit.safeSidebarView'},
	*/
	api.set(`ceccodeToolkit.devSidebarView.${publisher}-${name}`, valueMap);
```

- 添加按钮对应的命令方法
```
    // 注册 一个 命令，对应按钮发送的命令
	let disposable = vscode.commands.registerCommand('sample-toolkit-webview.helloWorld', () => {
		// 获取 需要打开的 URL 配置
		var url = vscode.workspace.getConfiguration("ceccode.sample.toolkit.webview").get<String>("url");
		const panel = vscode.window.createWebviewPanel(
			'testWelcome', // viewType
			"自定义欢迎页", // 视图标题
			vscode.ViewColumn.One, // 显示在编辑器的哪个部位
			{
				enableScripts: true, // 启用JS，默认禁用
			}
		);
		panel.webview.html = `<html  style="border: none; width: 100%; height: 100%;"   ><body style="border: none; width: 100%; height: 100%;"  ><iframe src="${url}" style="border: none; width: 100%; height: 100%;" /></body></html>`
	});
	context.subscriptions.push(disposable);
```
