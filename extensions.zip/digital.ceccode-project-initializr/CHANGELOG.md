# Change Log

All notable changes to the "ceccode-project-initializr" extension will be documented in this file.

Check [Keep a Changelog](http://keepachangelog.com/) for recommendations on how to structure this file.

## [Unreleased]

- Initial release

## v0.0.1
`2022-11-21`

- 🌟 项目初始化
- 🌟 完成<创建JAVA工程>功能

## v0.0.5

`2023-01-05`

- 🌟 组件新增checkbox筛选框，重构部分选中逻辑
- 🌟 调整组件主题配色，适配IDE主题切换

## v0.0.6

`2023-01-09`

- 🌟 新增搜索功能关键字"高亮"
- 🐞 按照设计稿调整组件配色
- 🐞 完善插件选中逻辑、搜索逻辑