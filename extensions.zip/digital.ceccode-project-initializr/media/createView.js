//@ts-check

// This script will be run within the webview itself
// It cannot access the main VS Code APIs directly.
(function () {
    const vscode = acquireVsCodeApi();

    document.querySelector('.add-java-button').addEventListener('click', () => {
        openJavaView();
    });



    function openJavaView() {
        vscode.postMessage({
            command: 'ceccode.initializr.openJavaView'

        })
    }
}());


