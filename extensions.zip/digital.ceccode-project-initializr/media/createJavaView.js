//@ts-check

// This script will be run within the webview itself
// It cannot access the main VS Code APIs directly.
(function () {
    const vscode = acquireVsCodeApi();

    // 隐藏环境变量配置
    document.getElementById('hiddenEnv')?.addEventListener('click', () => {
        document.getElementById('jdkEnv')?.style.setProperty('display', 'none');
    });

    // 切换tab
    document.getElementById('cecJdk')?.addEventListener('click', () => {
        document.getElementById('cecJdkTab')?.style.setProperty('border-right', '2px solid var(--vscode-textLink-foreground)');
        document.getElementById('cecJdkTab')?.style.setProperty('font-weight', '600');
        document.getElementById('cecJdkTab')?.style.setProperty('color', 'var(--vscode-textLink-foreground)');
        document.getElementById('otherJdkTab')?.style.setProperty('border-right', 'none');
        document.getElementById('otherJdkTab')?.style.setProperty('color', 'var(--vscode-settings-textInputForeground)');
        document.getElementById('otherJdkTab')?.style.setProperty('font-weight', '400');
        document.getElementById('cecJdkBlock')?.style.setProperty('display', 'grid');
        document.getElementById('otherJdkBlock')?.style.setProperty('display', 'none');
    });

    // 切换tab
    document.getElementById('otherJdk')?.addEventListener('click', () => {
        document.getElementById('cecJdkTab')?.style.setProperty('border-right', 'none');
        document.getElementById('cecJdkTab')?.style.setProperty('font-weight', '400');
        document.getElementById('cecJdkTab')?.style.setProperty('color', 'var(--vscode-settings-textInputForeground)');
        document.getElementById('otherJdkTab')?.style.setProperty('border-right', '2px solid var(--vscode-textLink-foreground)');
        document.getElementById('otherJdkTab')?.style.setProperty('font-weight', '600');
        document.getElementById('otherJdkTab')?.style.setProperty('color', 'var(--vscode-textLink-foreground)');
        document.getElementById('cecJdkBlock')?.style.setProperty('display', 'none');
        document.getElementById('otherJdkBlock')?.style.setProperty('display', 'grid');
    });
    
    document.querySelector('.generate-button')?.addEventListener('click', () => {
        generateJavaCode();
    });

    // 点击生成项目按钮
    function generateJavaCode() {
        let reg = new RegExp(' ', 'gm')

        let projectType
        let language
        let bootVersion
        let groupId
        let artifactId
        let projectName
        let description
        let packageName
        let packaging
        let javaVersion
        let dependencies
        
        let control = document.getElementsByClassName('control')
        let Project = control[0].getElementsByTagName('input')
        for (let i = 0; i < Project.length; ++i) {
            if (Project[i].checked) projectType = Project[i].value
        }
        let Language = control[1].getElementsByTagName('input')
        for (let i = 0; i < Language.length; ++i) {
            if (Language[i].checked) language = Language[i].value
        }
        let BootVersion = control[2].getElementsByTagName('input')
        for (let i = 0; i < BootVersion.length; ++i) {
            if (BootVersion[i].checked) bootVersion = BootVersion[i].value
        }
        groupId = document.getElementById('input-group')?.value
        artifactId = document.getElementById('input-artifact')?.value
        projectName = document.getElementById('input-name')?.value
        description = document.getElementById('input-description')?.value
        packageName = document.getElementById('input-packageName')?.value
        let control_inline = control[3].getElementsByClassName('control-inline')
        let Packaging = control_inline[5].getElementsByTagName('input')
        for (let i = 0; i < Packaging.length; ++i) {
            if (Packaging[i].checked) packaging = Packaging[i].value
        }
        let JavaVersion = control_inline[6].getElementsByTagName('input')
        for (let i = 0; i < JavaVersion.length; ++i) {
            if (JavaVersion[i].checked) javaVersion = JavaVersion[i].value
        }
        let DependenciesList = control[4].getElementsByClassName('dependencies-list')
        let dependenciesList = new Array()
        if (DependenciesList.length) {
            let Dependencies = DependenciesList[0].getElementsByClassName('dependency-item')        
            for (let i = 0; i < Dependencies.length; ++i) {
                dependenciesList.push(Dependencies[i].getAttribute('value'))
            }
        }
        dependencies = dependenciesList.join(',')

        // type=maven-project&language=java&bootVersion=2.7.3&baseDir=demo&groupId=com.example&artifactId=demo&name=demo&description=Demo%20project%20for%20Spring%20Boot&packageName=com.example.demo&packaging=jar&javaVersion=17&dependencies=tif
        vscode.postMessage({
            command: 'ceccode.initializr.createJavaProject',
            type: projectType,
            language: language,
            bootVersion: bootVersion,
            baseDir: artifactId.replace(reg, '%20'),
            groupId: groupId.replace(reg, '%20'),
            artifactId: artifactId.replace(reg, '%20'),
            name: projectName.replace(reg, '%20'),
            description: description.replace(reg, '%20'),
            packageName: packageName.replace(reg, '%20'),
            packaging: packaging,
            javaVersion: javaVersion,
            dependencies: dependencies
        })
    }

    // todo 接收 client 接口的配置信息
    window.addEventListener('message', event => {

        const message = event.data; // The JSON data our extension sent
        
        // console.info(message.bootVersion.default)
        // console.info(message.dependencies.values)
        configureType(message.type)
        configureRadio1(message.language, 1, 'language')
        configureRadio1(message.bootVersion, 2, 'bootVersion')
        configureText(message.groupId, 3, 0)
        configureText(message.artifactId, 3, 1)
        configureText(message.name, 3, 2)
        configureText(message.description, 3, 3)
        configureText(message.packageName, 3, 4)
        configureRadio2(message.packaging, 3, 5, 'packaging')
        configureRadio2(message.javaVersion, 3, 6, 'javaVersion')
        configureDependenciesGroup(message.dependencies)
    });

    vscode.postMessage({
        command: 'ceccode.initializr.loadJavaView'
    });

    function configureType(type) {
        let values = type['values']
        let defaultValue = type['default']
        let ul = document.getElementsByClassName('control')[0].getElementsByTagName('ul')[0]
        let count = 1
        for (let i = 0; i < values.length; ++i) {
            if (values[i].tags.format == 'project') {
                let li = document.createElement('li')
                let input = document.createElement('input')
                let label = document.createElement('label')
                input.type = 'radio'
                input.name = 'project'
                input.id = 'project' + count++
                input.value = values[i].id
                label.htmlFor = input.id
                label.innerText = values[i].name
                li.appendChild(input)
                li.appendChild(label)
                ul.appendChild(li)
                if(values[i].id == defaultValue) input.checked = true
            }          
        }
    }

    function configureRadio1(config, rank, _name) {
        let values = config['values']
        let defaultValue = config['default']
        let ul = document.getElementsByClassName('control')[rank].getElementsByTagName('ul')[0]
        let count = 1
        for (let i = 0; i < values.length; ++i) {
            let li = document.createElement('li')
            let input = document.createElement('input')
            let label = document.createElement('label')
            input.type = 'radio'
            input.name = _name
            input.id = _name + count++
            input.value = values[i].id
            label.htmlFor = input.id
            label.innerText = values[i].name
            li.appendChild(input)
            li.appendChild(label)
            ul.appendChild(li)
            if(values[i].id == defaultValue) input.checked = true       
        }
    }

    function configureText(config, rank, inline_rank) {
        let defaultValue = config['default']
        let control_inline = document.getElementsByClassName('control')[rank].getElementsByClassName('control-inline')[inline_rank]
        control_inline.getElementsByClassName('input')[0].value = defaultValue
    }

    function configureRadio2(config, rank, inline_rank, _name) {
        let values = config['values']
        let defaultValue = config['default']
        let ul = document.getElementsByClassName('control')[rank].getElementsByClassName('control-inline')[inline_rank].getElementsByTagName('ul')[0]
        let count = 1
        for (let i = 0; i < values.length; ++i) {
            let li = document.createElement('li')
            let input = document.createElement('input')  
            let label = document.createElement('label')           
            input.type = 'radio'
            input.name = _name
            input.id = _name + count++
            input.value = values[i].id
            label.htmlFor = input.id
            label.innerText = values[i].name
            li.appendChild(input)
            li.appendChild(label)
            ul.appendChild(li)
            if(values[i].id == defaultValue) input.checked = true       
        }
    }

    var Dependency = /** @class */ (function () {
        function Dependency(id, _name, description, versionRange, _links) {
            this.id = id;
            this._name = _name;
            this.description = description;
            this.versionRange = versionRange;
            this._links = _links;
        }
        return Dependency;
    }());

    var DependenciesGroup = /** @class */ (function () {
        function DependenciesGroup(groupName, values) {
            this.groupName = groupName;
            this.dependencies = new Array();
            for (var i = 0; i < values.length; ++i) {
                this.dependencies.push(new Dependency(values[i].id, values[i].name, values[i].description, values[i].versionRange, values[i]._links));
            }
        }
        DependenciesGroup.prototype.getDependencies = function () {
            return this.dependencies;
        };
        return DependenciesGroup;
    }());

    let displayLi = 0
    let dependenciesGroup = new Array()
    let dependenciesSelectedList = [] // 组件选中列表
    let dependenciesSelectedCacheList = [] // 组件弹层确认列表 - cache
    let dependenciesObjList = [] // 组件列表源信息
    let timer = null // 搜索计时器
    let searchList = [] // 搜索词列表

    window.addEventListener('DOMContentLoaded', () => {   
        
        function calculateResize () {
            let rem, wW;
            let whdef = 100/1200;// 表示1200的设计图,使用100PX的默认值,使用100px只是为了方便计算 其他值都可以
            if(document.body.clientWidth >= 1200){
                wW = 1200
            } else if(document.body.clientWidth < 1200 && document.body.clientWidth >= 768) {
                wW = document.body.clientWidth;// 当前窗口的宽度
            } else{
                wW = 768
            }
            rem = wW * whdef;// 以默认比例值乘以当前窗口宽度,得到该宽度下的相应FONT-SIZE值
            console.log(rem);
            document.getElementsByTagName("html")[0].style.fontSize=rem+'px'
        } 

        calculateResize()

        window.addEventListener('resize', ()=>{
            calculateResize()
        })     

        let spring_dialog_dependencies = document.getElementById('spring-dialog-dependencies')
        spring_dialog_dependencies?.style.setProperty('display', 'none')
        spring_dialog_dependencies?.getElementsByTagName('ul')[1].style.setProperty('display', 'none')
        // 监听ADD DEPENDENCIES按钮是否被点击，被点击则让spring-dialog-dependencies显示出来
        let explore_dependencies = document.getElementById('explore-dependencies')
        explore_dependencies?.addEventListener('click', (event) => {
            event.stopPropagation()
            // 复制一份
            dependenciesSelectedCacheList = [...dependenciesSelectedList]
            spring_dialog_dependencies?.style.removeProperty('display')
        })

        // 当spring-dialog-dependencies显示出来时，点击空白地方spring-dialog-dependencies隐藏
        spring_dialog_dependencies?.addEventListener('click', (event) => {
            spring_dialog_dependencies?.style.setProperty('display', 'none')
        })

        let close_dialog_dependencies = document.getElementsByClassName('close-dialog-dependencies')[0]

        // 当close_dialog_dependencies显示出来时，点击隐藏
        close_dialog_dependencies?.addEventListener('click', (event) => {
            spring_dialog_dependencies?.style.setProperty('display', 'none')
        })

        let dependencies = document.getElementById('dependencies')
        dependencies?.addEventListener('click', (event) => {
            event.stopPropagation()
        })

        // 让input-quicksearch在进行输入时同步改变value值
        let input_quicksearch = document.getElementById('input-quicksearch')
        input_quicksearch?.addEventListener('input', function (event) {
            const target = event.target
            input_quicksearch?.setAttribute('value', target.value)
            searchDependencies(target.value)
        })
        // input_quicksearch?.addEventListener('mouseover', function (event) {
        //     const target = event.target
        //     input_quicksearch?.setAttribute('title', target.value)
        // })

    })

    function configureDependenciesGroup(dependencies) {
        let values = dependencies['values']
        for (let i = 0; i < values.length; ++i) {
            let currentDependenciesGroup = new DependenciesGroup(values[i].name, values[i].values)
            dependenciesGroup.push(currentDependenciesGroup)
            addDependenciesGroup(currentDependenciesGroup)
            addSearchDependenciesGroup(currentDependenciesGroup)
            // 保存源信息
            addDependenciesObjList(currentDependenciesGroup)
        }
    }

    function addDependenciesObjList(item) {
        item.dependencies = item.dependencies.map(v => ({...v, groupName: item.groupName}))
        dependenciesObjList = [...dependenciesObjList, ...item.dependencies]
    }

    // 渲染组件列表
    function addDependenciesGroup(currentDependenciesGroup) {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        let no_dependency = dependencies?.getElementsByTagName('div')[1]
        if (no_dependency?.style.getPropertyValue('display') != 'none') {
            no_dependency?.style.setProperty('display', 'none')
            if (ul) ul[0].style.removeProperty('display')
        }
        if (ul) {
            let groupli = document.createElement('li')
            groupli.className = 'group-title'
            let span = document.createElement('span')
            let get_img2 = document.getElementById('get-img2')
            let jing = get_img2?.getElementsByTagName('img')[0].src
            span.innerHTML = `<img style="display:inline-block;width:12px;height:12px;" src="${jing}" alt="">` + currentDependenciesGroup.groupName
            groupli.appendChild(span)
            ul[0].appendChild(groupli)
            ++displayLi
            for (let i = 0; i < currentDependenciesGroup.dependencies.length; ++i) {
                let li = document.createElement('li')
                let a = document.createElement('a')
                let strong = document.createElement('strong')
                let span = document.createElement('span')
                const checkboxDiv = document.createElement('div');
                checkboxDiv.className = 'item-checkbox';
                const checkInput = document.createElement('div')
                checkInput.className = 'checkbox'
                checkboxDiv.append(checkInput)
                strong.innerText = currentDependenciesGroup.dependencies[i]._name
                span.innerText = currentDependenciesGroup.dependencies[i].description
                a.appendChild(checkboxDiv)
                a.appendChild(strong)
                a.appendChild(span)
                a.className = 'dependency'
                a.dataset.id = currentDependenciesGroup.dependencies[i].id
                li.appendChild(a)
                li.setAttribute('value', currentDependenciesGroup.dependencies[i].id)
                ul[0].appendChild(li)
                ++displayLi
                // 组件列表点击
                li.addEventListener('click', (event) => {
                    event.stopPropagation()
                    // li.style.setProperty('display', 'none')
                    // 设置list的选中状态
                    const aIndex = li.childNodes[0]
                    if(aIndex.className.includes('selected')) {
                        // 取消操作
                        const classNameList = aIndex.className.split(" ")
                        let currentClassName = ""
                        classNameList.forEach(v => {
                            if(v !== "selected") {
                                currentClassName += " " + v
                            }
                        })
                        a.className = currentClassName.trim()

                         // 搜索列表操作
                         let dependencies = document.getElementById('dependencies')
                         let ul = dependencies?.getElementsByTagName('ul')
                         if(ul?.length) {
                             ul[1].childNodes.forEach(item => {
                                 if(item?.className !== 'group-title') {
                                     const itemA = item.firstChild
                                     if(itemA.dataset.id === aIndex.dataset.id) {
                                         const classNameList = itemA.className.split(" ")
                                         let currentClassName = ""
                                         classNameList.forEach(v => {
                                             if(v !== "selected") {
                                                 currentClassName += " " + v
                                             }
                                         })
                                         itemA.className = currentClassName
                                     }
                                 }
                             })
                         }

                        dependenciesSelectedCacheList = dependenciesSelectedCacheList.filter(v => v !== aIndex.dataset.id)
                    }
                    else {
                        // 选中操作
                        aIndex.className += " selected"

                        // 搜索列表操作
                        let dependencies = document.getElementById('dependencies')
                        let ul = dependencies?.getElementsByTagName('ul')
                        if(ul?.length) {
                            ul[1].childNodes.forEach(item => {
                                if(item?.className !== 'group-title') {
                                    const itemA = item.firstChild
                                    if(itemA.dataset.id === aIndex.dataset.id) {
                                        itemA.className += " selected"
                                    }
                                }
                            })
                        }

                        dependenciesSelectedCacheList = [...new Set([...dependenciesSelectedCacheList, aIndex.dataset.id])]
                    }
                    showTotalNum()

                    --displayLi

                    // let hide = true
                    // for (let sibling = groupli.nextElementSibling; sibling && !sibling.getAttribute('class'); sibling = sibling.nextElementSibling) {
                    //     if (!sibling.getAttribute('style')) {
                    //         hide = false
                    //         break
                    //     }
                    // }
                    // if (hide) {
                    //     groupli.style.setProperty('display', 'none')
                    //     --displayLi
                    // }
                    // if (ul && displayLi <= 0) {
                    //     ul[0].style.setProperty('display', 'none')
                    //     no_dependency?.style.removeProperty('display')
                    // }
                    // if (ul) {
                    //     let targetid = li.getAttribute('value')
                    //     let searchli = ul[1].getElementsByTagName('li')
                    //     for (let i = 0; i < searchli.length; ++i) {
                    //         if (searchli[i].getElementsByClassName('group')[0].innerHTML == currentDependenciesGroup.groupName) {
                    //             if (searchli[i].getAttribute('value') == targetid) {
                    //                 searchli[i].style.setProperty('display', 'none')
                    //                 searchli[i].setAttribute('selected', 'selected')
                    //             }
                    //         }
                    //     }
                    // }
                    
                })
            }

        }

        
    }

    // 组件列表渲染 - 增加
    function addDependencyItem(groupName, dependency) {
        let dependencies_list = document.getElementById('dependencies-list')
        let ul = dependencies_list?.getElementsByTagName('ul')
        // let no_dependency = dependencies_list?.getElementsByTagName('div')[1]
        if (!ul?.length) {
            // no_dependency?.style.setProperty('display', 'none')
            let newul = document.createElement('ul')
            newul.className = 'dependencies-list'
            dependencies_list?.appendChild(newul)

            // newul.addEventListener('mouseenter', (event) => {
            //     event.stopPropagation()
            //     let a = newul.getElementsByClassName('icon')
            //     for (let i = 0; i < a.length; ++i) {
            //         a[i].getElementsByTagName('span')[0].style.setProperty('display', 'block')
            //     }
            // })
            // newul.addEventListener('mouseleave', (event) => {
            //     event.stopPropagation()
            //     let a = newul.getElementsByClassName('icon')
            //     for (let i = 0; i < a.length; ++i) {
            //         a[i].getElementsByTagName('span')[0].style.setProperty('display', 'none')
            //     }
            // })
        }
        if (ul) {
            let li = document.createElement('li')
            let div = document.createElement('div')
            let strong = document.createElement('strong')
            let span = document.createElement('span')
            let a = getRemoveA()
            a.addEventListener('click', (event) => {
                event.stopPropagation()
                li.remove()
                if (ul && ul[0].getElementsByTagName('li').length <= 0) {
                    ul[0].remove()
                    // no_dependency?.style.removeProperty('display')
                }
                const itemId = div.attributes.value.value;
                const list = document.querySelector('#dependencies')?.getElementsByTagName('ul')[0].childNodes
                list?.forEach(element => {
                    if(element.className !== 'group-title') {
                        if(element.attributes.value.value === itemId) {
                            element.childNodes[0].className = 'dependency'
                            dependenciesSelectedList = dependenciesSelectedList.filter(v => v !== itemId)
                            showTotalNum()
                        }
                    }
                })

                addDependency(groupName, dependency.id)
                addSearchDependency(groupName, dependency.id)
            })
            let get_img2 = document.getElementById('get-img2')
            let jing = get_img2?.getElementsByTagName('img')[0].src
            strong.innerHTML = dependency._name + `<span class="group"><img style="width:12px;height:12px;" src="${jing}" alt="">` + groupName + '</span>'
            span.innerText = dependency.description
            span.className = 'description'
            div.appendChild(strong)
            div.appendChild(span)
            div.appendChild(a)
            div.className = 'dependency-item'
            div.setAttribute('value', dependency.id)
            li.appendChild(div)
            ul[0].appendChild(li)
        }
    }

    // 移除逻辑
    function getRemoveA() {
        let get_img = document.getElementById('get-img')
        let remove = get_img?.getElementsByTagName('img')[0].src
        let removeDiv = document.createElement('div')
        removeDiv.innerHTML = '<span class="a-content"><img src="' + remove + '" alt=""> 移除</span>'
        removeDiv.className = 'icon'
        return removeDiv
    }

    function addDependency(groupName, id) {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        if (ul) {
            if (ul[0].style.getPropertyValue('display') == 'none') {
                ul[0].style.removeProperty('display')
                dependencies?.getElementsByTagName('div')[1].style.setProperty('display', 'none')
            }
            let groupli = ul[0].getElementsByClassName('group-title')
            for (let index = 0; index < groupli.length; ++index) {
                if (groupli[index].getElementsByTagName('span')[0].innerText == groupName) {
                    if (groupli[index].getAttribute('style') == 'display: none;') {
                        // groupli[index].removeAttribute('style')
                        groupli[index].style.removeProperty('display')
                        ++displayLi
                    }
                    for (let sibling = groupli[index].nextElementSibling; sibling && !sibling.getAttribute('class'); sibling = sibling.nextElementSibling) {
                        if (sibling.getAttribute('value') == id) {
                            // sibling.removeAttribute('style')
                            sibling.style.removeProperty('display')
                            ++displayLi
                            break
                        }
                    }
                    break
                }
            }
        }
    }

    // 渲染搜索列表
    function addSearchDependenciesGroup(currentDependenciesGroup) {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        if (ul) {
            for (let i = 0; i < currentDependenciesGroup.dependencies.length; ++i) {
                let li = document.createElement('li')
                let a = document.createElement('a')
                let strong = document.createElement('strong')
                let span = document.createElement('span')
                const checkboxDiv = document.createElement('div');
                checkboxDiv.className = 'item-checkbox';
                const checkInput = document.createElement('div')
                checkInput.className = 'checkbox'
                let get_img2 = document.getElementById('get-img2')
                let jing = get_img2?.getElementsByTagName('img')[0].src
                strong.innerHTML = '<span class="strong-text">' + currentDependenciesGroup.dependencies[i]._name +'</span>'+`<span class="group"><img style="display:inline-block;width:12px;height:12px;" src="${jing}" alt="">` + currentDependenciesGroup.groupName + '</span>'
                strong.dataset.text = currentDependenciesGroup.dependencies[i]._name
                span.innerText = currentDependenciesGroup.dependencies[i].description
                span.dataset.text = currentDependenciesGroup.dependencies[i].description
                span.className = 'description'
                checkboxDiv.append(checkInput)
                a.appendChild(checkboxDiv)
                a.appendChild(strong)
                a.appendChild(span)
                a.className = 'dependency'
                a.dataset.id = currentDependenciesGroup.dependencies[i].id
                li.appendChild(a)
                li.setAttribute('value', currentDependenciesGroup.dependencies[i].id)
                ul[1].appendChild(li)
                li.addEventListener('click', (event) => {
                    event.stopPropagation()
                    // li.style.setProperty('display', 'none')
                    
                    // 设置list的选中状态
                    const aIndex = li.childNodes[0]
                    if(aIndex.className.includes('selected')) {
                        // 取消操作
                        const classNameList = aIndex.className.split(" ")
                        let currentClassName = ""
                        classNameList.forEach(v => {
                            if(v !== "selected") {
                                currentClassName += " " + v
                            }
                        })
                        a.className = currentClassName.trim()

                        // 组件列表操作
                        let dependencies = document.getElementById('dependencies')
                        let ul = dependencies?.getElementsByTagName('ul')
                        if(ul?.length) {
                            ul[0].childNodes.forEach(item => {
                                
                                if(item?.className !== 'group-title') {
                                    const itemA = item.firstChild
                                    
                                    if(itemA.dataset.id === aIndex.dataset.id) {
                                        const classNameList = itemA.className.split(" ")
                                        let currentClassName = ""
                                        classNameList.forEach(v => {
                                            if(v !== "selected") {
                                                currentClassName += " " + v
                                            }
                                        })
                                        itemA.className = currentClassName
                                    }
                                }
                            })
                        }

                        dependenciesSelectedCacheList = dependenciesSelectedCacheList.filter(v => v !==  aIndex.dataset.id)
                    }
                    else {
                        // 选中操作
                        aIndex.className += " selected"

                        // 组件列表操作
                        let dependencies = document.getElementById('dependencies')
                        let ul = dependencies?.getElementsByTagName('ul')
                        if(ul?.length) {
                            ul[0].childNodes.forEach(item => {
                                if(item?.className !== 'group-title') {
                                    const itemA = item.firstChild
                                    if(itemA.dataset.id === aIndex.dataset.id) {
                                        itemA.className += " selected"
                                    }
                                }
                            })
                        }
                        dependenciesSelectedCacheList = [...new Set([...dependenciesSelectedCacheList, aIndex.dataset.id])]
                    }

                    showTotalNum()

                    // if (ul) {                        
                    //     let groupli = ul[0].getElementsByClassName('group-title')
                    //     for (let index = 0; index < groupli.length; ++index) {
                    //         if (groupli[index].getElementsByTagName('span')[0].innerText == currentDependenciesGroup.groupName) {
                    //             for (let sibling = groupli[index].nextElementSibling; sibling && !sibling.getAttribute('class'); sibling = sibling.nextElementSibling) {
                    //                 if (sibling.getAttribute('value') == currentDependenciesGroup.dependencies[i].id) {                                       
                    //                     // sibling.setAttribute('style', 'display: none;')
                    //                     sibling.style.setProperty('display', 'none')
                    //                     --displayLi
                    //                     break
                    //                 }
                    //             }
                    //             let hide = true
                    //             for (let sibling = groupli[index].nextElementSibling; sibling && !sibling.getAttribute('class'); sibling = sibling.nextElementSibling) {
                    //                 if (!sibling.getAttribute('style')) {
                    //                     hide = false
                    //                     break
                    //                 }
                    //             }
                    //             if (hide) {
                    //                 groupli[index].setAttribute('style', 'display: none;')
                    //                 groupli[index].style.setProperty('display', 'none')
                    //                 --displayLi
                    //             }
                    //             addDependencyItem(currentDependenciesGroup.groupName, currentDependenciesGroup.dependencies[i])
                    //             break
                    //         }
                    //     }
                    // }
                })
            }
        }
    }

    function addSearchDependency(groupName, id) {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        if (ul) {
            let li = ul[1].getElementsByTagName('li')
            for (let i = 0; i < li.length; ++i) {
                if (li[i].getElementsByClassName('group')[0].innerHTML == groupName) {
                    if (li[i].getAttribute('value') == id) {
                        li[i].style.removeProperty('display')
                        li[i].removeAttribute('selected')
                    }
                }
            }
        }
    }

    // 搜索逻辑
    function searchDependencies(value) {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        // let no_dependency = dependencies?.getElementsByTagName('div')[1]
        if (ul) {
            if (value) {
                searchList.push(value)
                // if (no_dependency?.style.getPropertyValue('display') != 'none') no_dependency?.style.setProperty('display', 'none')
                if (ul[0].style.getPropertyValue('display') != 'none') ul[0].style.setProperty('display', 'none')
                if (ul[1].style.getPropertyValue('display') == 'none') ul[1].style.removeProperty('display')
                ul[1].style.removeProperty('height')
                let reg = new RegExp(value, 'gi')
                let li = ul[1].getElementsByTagName('li')
                for (let i = 0; i < li.length; ++i) {
                    // 缓存
                    let strongText = li[i].getElementsByClassName('strong-text')[0].innerHTML
                    let descriptionText = li[i].getElementsByClassName('description')[0].innerHTML
                    
                    if ((strongText.search(reg) == -1 &&
                     descriptionText.search(reg) == -1) || 
                     (li[i].getAttribute('selected') == 'selected')) {
                        li[i].style.setProperty('display', 'none')
                    }
                    else {
                        // 开启计时器
                        clearTimeout(timer)
                        // ⚠ 高亮逻辑
                        timer = setTimeout(() => {
                            resetDirtyHTML()
                            // 取最后一个值
                            const value = searchList.slice(-1)
                            console.log("最终捕获", value)
                            let reg = new RegExp(value, 'gi')
                            ul[1].childNodes.forEach(element => {
                                let strongText = element.getElementsByClassName('strong-text')[0].innerHTML
                                let descriptionText = element.getElementsByClassName('description')[0].innerHTML
                                element.getElementsByClassName('strong-text')[0].innerHTML = element.getElementsByClassName('strong-text')[0].innerHTML.replace(reg, replacer)
                                element.getElementsByClassName('description')[0].innerHTML = element.getElementsByClassName('description')[0].innerHTML.replace(reg, replacer)
                                
                                if(strongText.search(reg) > -1 || descriptionText.search(reg) > -1) {
                                    element.style.removeProperty('display')
                                }
                            });
                            searchList = []
                        }, 1000)
                    }
                }
            }
            else {
                ul[1].style.setProperty('display', 'none')
                if (displayLi <= 0) {
                    // no_dependency?.style.removeProperty('display')
                }
                else {
                    resetDirtyHTML()
                    // 展示组件列表
                    ul[0].style.removeProperty('display')
                }
            }
        }

    }

    // 取到需要被替换的值
    function replacer(match, p1, p2, p3, offset, string) {
        return '<span class="highlight">' + match + '</span>';
      }

    // 重置搜索列表样式
    function resetDirtyHTML() {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        ul[1].childNodes.forEach(item => {
            item.getElementsByClassName('strong-text')[0].innerHTML = item.getElementsByTagName('strong')[0].dataset.text
            item.getElementsByClassName('description')[0].innerHTML = item.getElementsByClassName('description')[0].dataset.text
        })
    }

    // 重置搜索框
    function resetSearchInput() {
        let input_quicksearch = document.getElementById('input-quicksearch')
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        input_quicksearch.value = ""
        ul[1].style.display = "none"
        ul[0].style.display = "block"
    }

    // 显示总数
    function showTotalNum() {
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        let num = 0
        ul[0].childNodes.forEach(item => {
            if(item?.className !== 'group-title') {
                const itemA = item.firstChild
                if(itemA.className.includes('selected')) {
                    num ++
                }
            }
        })
        document.querySelector('#total-num').innerText = num
    }

    // 清空依赖列表
    function dependenciesListEmpty() {
        let dependencies_list = document.getElementById('dependencies-list')
        let ul = dependencies_list?.getElementsByTagName('ul')
        if(ul && ul.length) {
            ul[0].innerHTML = ""
        }
    }

    // 弹层 - 确定
    document.querySelector('#control-submit')?.addEventListener('click', function() {
        onModelSubmit()
    })

    // 弹层 - 取消
    document.querySelector('#control-cancel')?.addEventListener('click', function() {
        onModelCancel()
    })

    // 弹层 - 确定
    function onModelSubmit() {
        dependenciesListEmpty()

        if(dependenciesSelectedCacheList.length) {
            dependenciesObjList.forEach(v => {
                if(dependenciesSelectedCacheList.includes(v.id)) {
                    addDependencyItem(v.groupName, v)
                }
            })
        }
        else {
            let dependencies_list = document.getElementById('dependencies-list')
            dependencies_list?.getElementsByTagName('ul')[0]?.remove()
        }

        dependenciesSelectedList = [...dependenciesSelectedCacheList]
        dependenciesSelectedCacheList = []
        
        showTotalNum()
        resetSearchInput()
        document.getElementsByClassName('close-dialog-dependencies')[0].click()
    }

    // 弹层 - 取消
    function onModelCancel() {

        if(dependenciesSelectedList.length) {
            dependenciesListEmpty()
            dependenciesObjList.forEach(v => {
                if(dependenciesSelectedList.includes(v.id)) {
                    addDependencyItem(v.groupName, v)
                }
            })
        }
        else {
            let dependencies_list = document.getElementById('dependencies-list')
            dependencies_list?.getElementsByTagName('ul')[0]?.remove()
        }
        
        dependenciesSelectedCacheList = []

        // 清理已选中的内容
        let dependencies = document.getElementById('dependencies')
        let ul = dependencies?.getElementsByTagName('ul')
        if(ul?.length) {
            for (let element of ul) {
                element.childNodes.forEach(item => {
                    if(item?.className !== 'group-title') {
                        if(dependenciesSelectedList.includes(item.attributes.value.value)) {
                            const itemA = item.firstChild
                            itemA.className = "dependency selected"
                        }
                        else {
                            const itemA = item.firstChild
                            itemA.className = "dependency"
                        }
                    }
                })
            };
        }

        showTotalNum()
        resetSearchInput()
        document.getElementsByClassName('close-dialog-dependencies')[0].click()
    }
}());


