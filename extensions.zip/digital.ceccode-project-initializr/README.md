# ceccode-project-initializr README

ece 项目初次化工程

## Features

支持创建java 项目

## Requirements



## Extension Settings
```
  // Default language.
  "ceccode.initializr.defaultLanguage": "Java",

  // Default Java version.
  "ceccode.initializr.defaultJavaVersion": "11",

  // Default value for Artifact Id.
  "ceccode.initializr.defaultArtifactId": "demo",

  // Default value for Group Id.
  "ceccode.initializr.defaultGroupId": "com.example",

  // Spring Initializr Service URL(s). If more than one url is specified, it requires you to select one every time you create a project.
  "ceccode.initializr.serviceUrl": [ "https://cecide.digitalgd.com.cn/initializr/" ],

  // Default value for Packaging. Supported values are "JAR" and "WAR".
  "ceccode.initializr.defaultPackaging": "JAR",

  // Default value for the method of openining the newly generated project. Supported values are "", "Open" and "Add to Workspace".
  "ceccode.initializr.defaultOpenProjectMethod": "Add to Workspace",
```

## Known Issues



## Release Notes



### 0.0.1

支持创建java 工程
---

**Enjoy!**
